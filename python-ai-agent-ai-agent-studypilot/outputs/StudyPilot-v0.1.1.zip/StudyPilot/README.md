# StudyPilot 📚

一个逐步构建的开源教育 AI Agent 项目。**当前发布 v0.1.1，完成第一阶段：可以本地运行的学习管理基础。**

v0.1.1 重新设计了界面：参考 [Offmap](https://www.offmap-x.ai/) 的大标题与分区思路，采用暖白纸张底色、珊瑚色重点、横向导航和原创 SVG 学习插画。首页新增可用学习日展示，以及直接进入任务和档案的快捷按钮。原来的 SQLite 数据无需迁移，读写确认逻辑保留。字体和图片均使用本地资源，不依赖外部字体服务。

适合每周只有少量学习时间的学生。默认档案草稿为每周 8 小时，周五 120 分钟、周六和周日各 180 分钟，周五至周日可用电脑。默认值可修改，不会自动保存为真实档案；数据库没有示例任务或虚构学习记录。

2026-10-16 界面更新：圆角导航与选中胶囊、按钮悬停和按压回弹、学习日卡片错峰入场、插画悬停摆动、输入聚焦高亮、下拉菜单与折叠内容入场。动画使用本地 CSS，遵循系统“减少动态效果”设置，触屏不启用悬停位移动画。

## 已实现与边界

- 中文 Streamlit 界面：学习概览、学习档案、学习任务、学习记录。
- 学习档案：目标、各科目基础与优先级、速度、偏好、每天可用时间与设备。
- 任务创建、编辑、删除、截止日期、预计分钟、完成状态和电脑需求。
- 按日期记录真实学习分钟，查看每周历史；误记后可确认删除并重录。
- SQLite 首次自动建表，重启保留数据；每次写入学习数据前必须勾选确认并点击提交。
- 输入校验、参数化 SQL、事务、任务和档案版本检查，以及任务变更历史。
- 基础图表：实际学习分钟、科目投入比例、每周学习历史。

**尚未实现**：规则式排课、自然语言工具调用、AI 建议、考试优先级调整、目标里程碑完成率。此版本尚不是完整 Agent，配置 Key 也不会调用模型。每天设备限制目前用于档案存储，不会在手动创建任务时替你排课。

## Windows 安装与运行

需要 Python 3.11+、Windows 10/11；本次验证环境详见 [验证记录](VALIDATION.md)。首次安装依赖需要网络，安装后核心功能可离线使用。

**双击启动**：双击项目中的 `Start-StudyPilot.cmd`，它会启动本地网站并优先用 Google Chrome 打开 [http://127.0.0.1:8501/](http://127.0.0.1:8501/)。保持服务窗口打开，按 `Ctrl+C` 停止；下次使用再双击即可。已经运行时会直接打开现有服务。8501 端口应专用于 StudyPilot，不要同时运行另一个 Streamlit 应用。

启动入口优先使用项目 `.venv`；在当前开发工作区可复用已安装的 `work\.venv`。解压到其它位置首次启动时，会使用已安装的 Python 创建 `.venv` 并联网安装依赖，不会安装 Python 本身。仍可按下方步骤手动安装。此网址仅在这台电脑上、服务运行期间可用，无需公网部署。

解压或克隆项目。在 PowerShell 中进入包含 `app.py` 的 StudyPilot 目录：

```powershell
cd "C:\你的目录\StudyPilot"
py --version
py -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m streamlit run app.py
```

这里直接调用虚拟环境里的 Python，不需要执行 `Activate.ps1`，也不用修改 PowerShell 执行策略。若没有 `py` 命令，安装 Python 并选择添加到 PATH，或使用可用的 `python` 命令替代前两行的 `py`。

浏览器打开 [http://localhost:8501](http://localhost:8501)。停止服务：在运行窗口按 `Ctrl+C`。

第二次启动只需要：

```powershell
cd "C:\你的目录\StudyPilot"
.\.venv\Scripts\python.exe -m streamlit run app.py
```

默认数据库路径是项目内的 `data\studypilot.db`，与启动终端所在位置无关。默认只监听 `127.0.0.1`，供你自己在本机使用。

若端口已占用：

```powershell
.\.venv\Scripts\python.exe -m streamlit run app.py --server.port 8502
```

此时打开 [http://localhost:8502](http://localhost:8502)。

## 第一次使用：只做四件事

默认用户导航只有“学习概览、学习档案、学习任务、学习记录”，“开发进度”不会显示，也不能通过修改网页导航状态访问。

1. 打开“学习档案”，检查 8 小时及周末设备默认值，勾选确认并保存。
2. 打开“学习任务”，创建“写一个问候程序”，预计 30 分钟，需要电脑。
3. 真正做完学习后，在“学习记录”填写实际学习日期和分钟；在任务页将状态改为“已完成”并确认。
4. 打开“学习概览”，看真实时长和完成率；重启程序确认数据仍存在。

不要一次创建几十个任务。先用一个小任务跑通流程。

## 学习目标由你决定

新档案的学习目标为空。输入框中的浅色文字只是填写示例，既不是输入值，也不会自动保存。每行可以写一个目标，直接修改或删除对应行；清空输入框后，勾选确认并点击“保存档案”，即可删除全部目标。目标可以为空，其余档案仍然能保存。正式目标只有确认保存后才更新；刷新或重新打开网站会从 SQLite 读取已保存内容，未提交的草稿不保证保留。

“AI 帮我制定目标”是可展开的入口，当前明确显示“AI 目标建议尚未启用”，并提供帮助你思考需求的问题。本版没有生成目标建议、建议采纳/编辑/忽略或模型对话能力；配置 Key 也不会生成推荐。入口只切换说明面板，不提交表单或写数据库。以后接入时，建议应作为临时内容，采纳或编辑后仍须由用户明确确认保存。

旧版只在表单确认保存时写入目标，没有记录目标来源。因此不会仅凭“文字与示例相同”删除旧记录，而是在目标区域提示你自行核对；自定义目标和学习记录均保留。新用户的旧默认示例已移到 placeholder，不需要数据迁移。

当前是本机单档案版本，没有账号或登录功能。不同使用者需要分别使用自己的数据库，通过 `STUDYPILOT_DB` 指定各自路径；打开同一个数据库的浏览器会读到同一份档案。它尚不是带账号隔离的多人服务。

## 统计口径与历史

- 一周从周一开始，到周日结束；默认日期使用运行电脑的本地日历日期，学习日期由你在表单中选择。
- 本周到期任务完成率 = 本周截止且未删除任务中，当前状态为“已完成”的数量 ÷ 该周任务数量。无到期任务显示“—”，不会把它当成 0%。
- 首页的七天时间与设备来自当前学习档案，是你的可用时间，不是自动生成的任务计划；默认草稿会明确标注。
- 查看过去周的完成率仍采用任务**当前**状态，不宣称是那周结束时的完成率。任务原始变更快照另存于 `task_events`。
- 实际时间按 `study_sessions.study_date` 汇总。任务标记完成不会自动填时间，预计时间也不计入实际时间。
- 科目投入比例只按真实分钟计算。任务修改科目后，旧记录仍使用学习发生时的科目。
- 任务删除采用软删除：从任务列表与完成率分母隐藏，已有时长和变更记录保留。无法从界面撤销任务删除，因此提交前请核对。
- 删除错误的学习记录会移除该记录，统计相应改变。每周历史由 SQLite 中的原始日期记录即时汇总；没有记录的周不等于没有学习。
- 目标目前是文字，尚无可衡量的里程碑，所以不生成“目标完成 60%”这样的数字。

## 开发者查看开发进度

开发者在 PowerShell 启动前显式设置 `STUDYPILOT_DEV_MODE=1`，才会显示开发页；网页没有开启入口，URL 参数不能启用它。例如在独立端口运行开发实例：

```powershell
$env:STUDYPILOT_DEV_MODE = "1"
.\.venv\Scripts\python.exe -m streamlit run app.py --server.address 127.0.0.1 --server.port 8502
```

退出开发实例后，执行 `Remove-Item Env:STUDYPILOT_DEV_MODE` 再启动即恢复用户模式。变量为空、未设置或不等于 `1` 均关闭开发页；旧开发页会话回到学习概览。当前是本机单用户应用，这是进程级开发配置，不是账号角色认证；同一个开发实例的所有访问者都可看到开发页，因此普通用户只使用默认实例。

## API 配置：为第三阶段预留

第一阶段完全不需要 API Key，也不会发送数据。未来第三阶段通过 OpenAI Python SDK 加入工具调用时，可在当前 PowerShell 会话配置：

```powershell
$env:OPENAI_API_KEY = "你的 API Key"
$env:OPENAI_MODEL = "你有权限使用的模型名称"
# 当前第一阶段不需要安装；第三阶段实现后才使用：
# .\.venv\Scripts\python.exe -m pip install -r requirements-ai.txt
```

设置后在同一个终端启动应用。界面只提示是否检测到 Key，不显示它。当前没有读取 `OPENAI_MODEL`、自动加载 `.env` 或验证 Key 的逻辑。

不要把真实 Key 写进源代码、截图或 Git 仓库。`.env.example` 仅解释变量名。若要清除当前会话 Key：

```powershell
Remove-Item Env:OPENAI_API_KEY -ErrorAction SilentlyContinue
```

## 数据位置、备份与隐私

只需学习资料和记录，不接入学校账号，不要求姓名、学校、出生日期、联系方式或住址。自由文本请尽量只写学习内容。SQLite 是本地明文文件，当前版本没有登录或加密，不应公开部署或共享有个人记录的数据库。

可选自定义数据库位置：

```powershell
$env:STUDYPILOT_DB = "C:\你的目录\StudyPilot-data\studypilot.db"
.\.venv\Scripts\python.exe -m streamlit run app.py
```

先 `Ctrl+C` 停止服务，再复制整个 `data` 目录备份。恢复时先停服务，再替换数据库文件；不要用空数据库覆盖需要保留的记录。更高版本数据库会被拒绝打开，不会自动重置。

建空表属于首次启动的必要初始化；用户档案、任务和学习记录都不会自动写入。`confirmed=True` 是应用层确认约束，未来 Agent 仍需通过用户明确批准后调用，不能由模型自行批准。

## 运行自动化测试

在项目根目录执行：

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
```

测试使用临时目录和临时数据库，**不会读写你的实际学习数据库**。包含真实数据库持久化、校验、确认拦截、冲突、删除后的历史、周边界，以及 Streamlit 表单从点击到数据库的完整路径。无需另装 pytest。

只运行数据库和统计测试（不需要 Streamlit）：

```powershell
py -m unittest tests.test_database -v
```

## 项目结构

```text
StudyPilot/
├─ app.py                    # 中文界面与交互确认
├─ studypilot/
│  ├─ __init__.py
│  ├─ models.py              # 数据模型、默认值、输入校验
│  ├─ database.py            # SQLite 与增删改查
│  ├─ progress.py            # 周统计，纯函数
│  └─ theme.py               # 页面展示组件，动态文字经过 HTML 转义
├─ assets/
│  ├─ style.css              # 全站排版与响应式样式
│  └─ learning-map.svg       # 原创插画，离线可用
├─ tests/                    # 临时数据库与 Streamlit 自动化测试
├─ .streamlit/config.toml    # 浅色主题、本机监听、关闭使用统计
├─ data/studypilot.db        # 首次启动生成，不上传 Git
├─ requirements.txt          # 第一阶段必需依赖
├─ requirements-ai.txt       # 第三阶段可选依赖
├─ .env.example
├─ .gitignore
├─ LEARNING.md               # 分模块 Python 课程
├─ VALIDATION.md             # 已验证和未验证的范围
└─ LICENSE                   # MIT 开源许可证
```

## 开发路线

第一阶段已完成：可靠的本地学习管理。第二阶段会新增规则式生成器，验证每周总预算、每日时间和设备；无法安排的任务明确列出，生成预览经确认后再保存。

第三阶段会新增 OpenAI 工具调用循环：`get_study_profile`、`get_tasks`、`get_progress` 只读；`create_task`、`update_task`、`generate_schedule` 的修改先生成可审阅提案。模型提出调整 → 用户接受或拒绝 → 接受后按原数据版本提交事务。模型不能直接传入用户确认。比如“数学太难，减少 Python 时间”必须先读取资料和计划，再解释理由并等待确认。

第四阶段再补真实记录驱动的建议、目标里程碑、可视化和协作文档。当前先提供基础统计、测试和 MIT 许可证，不提前做复杂服务。

## 上传到 GitHub

仓库还未创建或发布。在项目目录中可以执行：

```powershell
git init
git add .
git status
# 确认没有 data/、.venv/、.env 或真实 Key 后再提交：
git commit -m "Build StudyPilot phase 1 MVP"
```

然后在 GitHub 创建空仓库，按该仓库页面给出的命令设置 remote 并推送。首次提交前 `.gitignore` 会忽略学习数据与密钥；已被跟踪的文件不会因添加忽略规则自动解除跟踪。

建议每次改动都先运行测试。入门练习见 [LEARNING.md](LEARNING.md)。界面测试方法采用 [Streamlit 官方 AppTest 文档](https://docs.streamlit.io/develop/api-reference/app-testing/st.testing.v1.apptest)，图表 API 参考 [官方 st.bar_chart 文档](https://docs.streamlit.io/develop/api-reference/charts/st.bar_chart)。
