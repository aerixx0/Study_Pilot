"""SQLite 数据层：参数化 SQL、显式确认、事务和版本检查。"""

from contextlib import contextmanager
from datetime import date, datetime, timezone
import json
from pathlib import Path
import sqlite3

from .models import StudyProfile, TaskInput, ValidationError, clean_text, iso_date, minutes


class ConfirmationRequired(ValueError):
    pass


class ConflictError(ValueError):
    pass


def require_confirmation(confirmed):
    # UI 与将来的 Agent 必须显式传入 True；不是登录或安全权限系统。
    if confirmed is not True:
        raise ConfirmationRequired("请先勾选确认，再提交更改。")


def now_utc():
    return datetime.now(timezone.utc).isoformat(timespec="microseconds")


class Database:
    def __init__(self, path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.initialize()

    @contextmanager
    def connection(self):
        """with 块成功时提交，出错时回滚，最终关闭连接，避免 Windows 文件锁。"""
        conn = sqlite3.connect(self.path, timeout=10)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON")
        try:
            with conn:
                yield conn
        finally:
            conn.close()

    def initialize(self):
        """首次运行创建空表；重复启动不会重置已有数据。"""
        with self.connection() as conn:
            version = conn.execute("PRAGMA user_version").fetchone()[0]
            if version not in (0, 1):
                raise ValidationError("数据库版本较新，请使用匹配版本的 StudyPilot。")
            conn.executescript("""
                CREATE TABLE IF NOT EXISTS profile (
                    id INTEGER PRIMARY KEY CHECK(id = 1),
                    payload TEXT NOT NULL,
                    version INTEGER NOT NULL DEFAULT 1,
                    updated_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS tasks (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    title TEXT NOT NULL, subject TEXT NOT NULL, due_date TEXT NOT NULL,
                    estimated_minutes INTEGER NOT NULL CHECK(estimated_minutes > 0),
                    priority TEXT NOT NULL, status TEXT NOT NULL,
                    requires_computer INTEGER NOT NULL CHECK(requires_computer IN (0, 1)),
                    notes TEXT NOT NULL DEFAULT '',
                    created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
                    completed_at TEXT, deleted_at TEXT,
                    version INTEGER NOT NULL DEFAULT 1
                );
                CREATE TABLE IF NOT EXISTS study_sessions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    task_id INTEGER NOT NULL REFERENCES tasks(id),
                    subject TEXT NOT NULL,
                    study_date TEXT NOT NULL,
                    minutes INTEGER NOT NULL CHECK(minutes > 0),
                    note TEXT NOT NULL DEFAULT '',
                    created_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS task_events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    task_id INTEGER NOT NULL REFERENCES tasks(id),
                    action TEXT NOT NULL, snapshot TEXT NOT NULL, created_at TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS sessions_date ON study_sessions(study_date);
                CREATE INDEX IF NOT EXISTS tasks_due ON tasks(due_date);
                PRAGMA user_version = 1;
            """)

    def get_study_profile(self):
        """新档案目标为空；旧数据无来源标记，读取时不按文字猜测或删除目标。"""
        with self.connection() as conn:
            row = conn.execute("SELECT * FROM profile WHERE id = 1").fetchone()
        if row is None:
            return StudyProfile(), 0
        try:
            profile = StudyProfile(**json.loads(row["payload"]))
            profile.validated()
        except (ValueError, TypeError, AttributeError, KeyError):
            raise ValidationError("学习档案数据无法读取，请从备份恢复数据库。") from None
        return profile, row["version"]

    def save_profile(self, profile: StudyProfile, *, expected_version: int, confirmed=False):
        require_confirmation(confirmed)
        payload = json.dumps(profile.validated(), ensure_ascii=False)
        with self.connection() as conn:
            if expected_version == 0:
                try:
                    conn.execute("INSERT INTO profile VALUES (1, ?, 1, ?)", (payload, now_utc()))
                except sqlite3.IntegrityError:
                    raise ConflictError("档案已在其他页面保存，请刷新后重试。") from None
            else:
                result = conn.execute("UPDATE profile SET payload=?, version=version+1, updated_at=? WHERE id=1 AND version=?", (payload, now_utc(), expected_version))
                if result.rowcount != 1:
                    raise ConflictError("档案已发生变化，请刷新后重新确认。")

    def get_tasks(self, *, include_deleted=False):
        with self.connection() as conn:
            sql = "SELECT * FROM tasks" + ("" if include_deleted else " WHERE deleted_at IS NULL")
            return [dict(row) for row in conn.execute(sql + " ORDER BY due_date, id")]

    def get_task(self, task_id, *, include_deleted=False):
        with self.connection() as conn:
            row = conn.execute("SELECT * FROM tasks WHERE id=?" + ("" if include_deleted else " AND deleted_at IS NULL"), (task_id,)).fetchone()
        if row is None:
            raise ValidationError("任务不存在或已删除，请刷新页面。")
        return dict(row)

    @staticmethod
    def _event(conn, task_id, action):
        snapshot = dict(conn.execute("SELECT * FROM tasks WHERE id=?", (task_id,)).fetchone())
        conn.execute("INSERT INTO task_events(task_id, action, snapshot, created_at) VALUES (?, ?, ?, ?)", (task_id, action, json.dumps(snapshot, ensure_ascii=False), now_utc()))

    def create_task(self, task: TaskInput, *, confirmed=False):
        require_confirmation(confirmed)
        data = task.validated()
        timestamp = now_utc()
        with self.connection() as conn:
            result = conn.execute("""INSERT INTO tasks
                (title,subject,due_date,estimated_minutes,priority,status,requires_computer,notes,created_at,updated_at,completed_at)
                VALUES (?,?,?,?,?,?,?,?,?,?,?)""", (*data.values(), timestamp, timestamp, timestamp if task.status == "已完成" else None))
            task_id = result.lastrowid
            self._event(conn, task_id, "创建")
        return task_id

    def update_task(self, task_id, task: TaskInput, *, expected_version: int, confirmed=False):
        require_confirmation(confirmed)
        data = task.validated()
        timestamp = now_utc()
        with self.connection() as conn:
            result = conn.execute("""UPDATE tasks SET title=?,subject=?,due_date=?,estimated_minutes=?,priority=?,status=?,requires_computer=?,notes=?,
                updated_at=?, completed_at=CASE WHEN ? != '已完成' THEN NULL ELSE COALESCE(completed_at, ?) END,
                version=version+1 WHERE id=? AND version=? AND deleted_at IS NULL""", (*data.values(), timestamp, task.status, timestamp, task_id, expected_version))
            if result.rowcount != 1:
                raise ConflictError("任务已被修改或删除，请刷新后重新确认。")
            self._event(conn, task_id, "更新")

    def delete_task(self, task_id, *, expected_version: int, confirmed=False):
        """软删除任务，保留学习时长和变更历史，避免统计凭空减少。"""
        require_confirmation(confirmed)
        with self.connection() as conn:
            result = conn.execute("UPDATE tasks SET deleted_at=?,updated_at=?,version=version+1 WHERE id=? AND version=? AND deleted_at IS NULL", (now_utc(), now_utc(), task_id, expected_version))
            if result.rowcount != 1:
                raise ConflictError("任务已被修改或删除，请刷新后重新确认。")
            self._event(conn, task_id, "删除")

    def log_session(self, task_id, study_date, duration, note="", *, confirmed=False):
        """按实际发生的日期记录时长；不会自动完成任务，也不填造历史。"""
        require_confirmation(confirmed)
        iso_date(study_date, "学习日期")
        if date.fromisoformat(study_date) > date.today():
            raise ValidationError("实际学习日期不能在未来。")
        minutes(duration, "实际学习时长")
        note = clean_text(note, "学习记录备注", 1000, False)
        with self.connection() as conn:
            row = conn.execute("SELECT subject FROM tasks WHERE id=? AND deleted_at IS NULL", (task_id,)).fetchone()
            if row is None:
                raise ValidationError("任务不存在或已删除，请刷新页面。")
            result = conn.execute("INSERT INTO study_sessions(task_id,subject,study_date,minutes,note,created_at) VALUES (?,?,?,?,?,?)", (task_id, row["subject"], study_date, duration, note, now_utc()))
        return result.lastrowid

    def delete_session(self, session_id, *, confirmed=False):
        require_confirmation(confirmed)
        with self.connection() as conn:
            if conn.execute("DELETE FROM study_sessions WHERE id=?", (session_id,)).rowcount != 1:
                raise ValidationError("学习记录不存在，请刷新页面。")

    def get_sessions(self):
        with self.connection() as conn:
            return [dict(row) for row in conn.execute("""SELECT s.*, t.title AS task_title, t.deleted_at FROM study_sessions s
                JOIN tasks t ON t.id=s.task_id ORDER BY s.study_date DESC, s.id DESC""")]

    def get_events(self):
        with self.connection() as conn:
            return [dict(row) for row in conn.execute("SELECT * FROM task_events ORDER BY id DESC")]
