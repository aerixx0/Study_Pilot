"""账号界面：只有验证通过的会话才能进入学习页面。"""

import streamlit as st

from .auth import AuthError
from .database import ConfirmationRequired
from .models import ValidationError
from .theme import page_intro


def clear_account_state():
    """退出或切换账号时清空整个页面草稿，避免把上一人的输入带给下一人。"""
    for key in list(st.session_state):
        del st.session_state[key]


def show_recovery_receipt(username, code, message):
    clear_account_state()
    st.session_state["recovery_receipt"] = {"username": username, "code": code, "message": message}
    st.rerun()


def matching_passwords(password, confirmation):
    if password != confirmation:
        raise ValidationError("两次输入的密码不一致。")


def login_gate(auth):
    """返回服务端认证后的 Account；匿名请求只渲染登录页，不创建学习数据库。"""
    token = st.session_state.get("auth_token")
    account = auth.authenticate(token)
    if account:
        return account
    if token:
        clear_account_state()
        st.session_state["auth_notice"] = "登录已过期或已在其他位置退出，请重新登录。"
    page_intro("HELLO", "为你的学习，留一个位置", "登录自己的账号，让目标和每一步努力都有归处。", "YOUR OWN LEARNING SPACE")
    if "auth_notice" in st.session_state:
        st.info(st.session_state.pop("auth_notice"))
    receipt = st.session_state.get("recovery_receipt")
    if receipt:
        st.success(receipt["message"])
        st.write(f"用户名：{receipt['username']}")
        st.warning("请现在保存恢复码。离开后无法再次查看；忘记密码时，需要用户名和恢复码一起重置。旧恢复码已失效。")
        st.code(receipt["code"], language=None)
        st.caption("请放在你自己的密码管理器或安全位置，不要分享给他人。")
        if st.button("我已妥善保存，去登录", type="primary", key="recovery_ack"):
            clear_account_state()
            st.rerun()
        return None

    mode = st.radio("账号操作", ("登录", "注册账号", "找回密码"), horizontal=True, key="auth_mode")
    try:
        if mode == "登录":
            with st.form("login_form", clear_on_submit=True):
                username = st.text_input("用户名", max_chars=32, key="login_username")
                password = st.text_input("密码", type="password", max_chars=128, key="login_password")
                if st.form_submit_button("登录", type="primary", width="stretch"):
                    token = auth.login(username, password)
                    clear_account_state()
                    st.session_state["auth_token"] = token
                    st.rerun()
            st.caption("会话最长 12 小时，30 分钟无操作会过期。刷新页面或打开新标签页后，请重新登录；已保存的数据不会丢失。")
        elif mode == "注册账号":
            with st.form("registration_form", clear_on_submit=True):
                username = st.text_input("用户名", max_chars=32, key="register_username", help="3–32 位英文字母、数字或下划线，不区分大小写。无需真实姓名。")
                password = st.text_input("设置密码", type="password", max_chars=128, key="register_password", help="15–128 个字符，建议使用容易记住的长短语。")
                repeat = st.text_input("再次输入密码", type="password", max_chars=128, key="register_repeat")
                confirmed = st.checkbox("我确认创建自己的本地账号", key="register_confirm")
                if st.form_submit_button("创建账号", type="primary", width="stretch"):
                    matching_passwords(password, repeat)
                    account, code = auth.register(username, password, confirmed=confirmed)
                    show_recovery_receipt(account.username, code, "账号已创建。请先保存恢复码，再登录。")
            st.caption("只需要用户名和密码，不需要邮箱、手机号或学校账号。每个账号从空白的学习目标开始。")
        else:
            st.caption("输入注册或上次改密时保存的恢复码。没有恢复码时，本版无法通过邮箱或短信找回。")
            with st.form("reset_form", clear_on_submit=True):
                username = st.text_input("用户名", max_chars=32, key="reset_username")
                code = st.text_input("恢复码", type="password", max_chars=128, key="reset_code")
                password = st.text_input("新密码", type="password", max_chars=128, key="reset_password")
                repeat = st.text_input("再次输入新密码", type="password", max_chars=128, key="reset_repeat")
                confirmed = st.checkbox("我确认重置密码并退出该账号的所有会话", key="reset_confirm")
                if st.form_submit_button("重置密码", type="primary", width="stretch"):
                    matching_passwords(password, repeat)
                    next_code = auth.reset_password(username, code, password, confirmed=confirmed)
                    show_recovery_receipt(username.strip().lower(), next_code, "密码已重置，所有旧会话已退出。请保存新的恢复码。")
    except (AuthError, ValidationError, ConfirmationRequired) as exc:
        st.error(str(exc))
    return None


def account_bar(auth, account):
    with st.container(key="account-bar"):
        left, right = st.columns([6, 1])
        left.caption(f"已登录：{account.username} · {'开发者' if account.role == 'developer' else '个人学习空间'}")
        if right.button("退出登录", key="logout", width="stretch"):
            auth.logout(st.session_state.get("auth_token"))
            clear_account_state()
            st.rerun()


def account_settings(auth, account):
    page_intro("ACCOUNT", "安心管理你的账号", "密码更新后，所有旧会话与旧恢复码都会失效。", "ACCOUNT SETTINGS")
    st.write(f"用户名：{account.username}")
    with st.form("change_password_form", clear_on_submit=True):
        current = st.text_input("当前密码", type="password", max_chars=128, key="change_current")
        password = st.text_input("新密码", type="password", max_chars=128, key="change_password")
        repeat = st.text_input("再次输入新密码", type="password", max_chars=128, key="change_repeat")
        confirmed = st.checkbox("我确认修改密码并退出所有会话", key="change_confirm")
        if st.form_submit_button("更新密码", type="primary"):
            try:
                matching_passwords(password, repeat)
                code = auth.change_password(st.session_state.get("auth_token"), current, password, confirmed=confirmed)
                show_recovery_receipt(account.username, code, "密码已更新。请保存新恢复码，然后重新登录。")
            except (AuthError, ValidationError, ConfirmationRequired) as exc:
                st.error(str(exc))
    st.caption("忘记或遗失恢复码时，可以在记得当前密码的情况下，通过更新密码获取新的恢复码。")
