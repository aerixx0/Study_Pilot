"""注册→恢复码→登录→退出，以及密码重置的页面级回归。"""

import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from streamlit.testing.v1 import AppTest

from studypilot.auth import AuthStore
from studypilot.models import StudyProfile
from tests.test_auth import PASSWORD, NEW_PASSWORD


ROOT = Path(__file__).resolve().parents[1]


class AuthUITests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.auth_root = Path(self.temp.name) / "accounts"
        environment = patch.dict(os.environ, {"STUDYPILOT_AUTH_DIR": str(self.auth_root),
            "STUDYPILOT_DB": str(Path(self.temp.name) / "legacy.db"), "STUDYPILOT_DEV_MODE": "1"})
        environment.start()
        self.addCleanup(environment.stop)
        self.app = AppTest.from_file(str(ROOT / "app.py"), default_timeout=30).run()
        self.auth = AuthStore(self.auth_root)

    def click(self, label):
        next(b for b in self.app.button if b.label == label).click().run()
        self.assertEqual(len(self.app.exception), 0)

    def login(self, username="student", password=PASSWORD):
        self.app.text_input(key="login_username").set_value(username)
        self.app.text_input(key="login_password").set_value(password)
        self.click("登录")

    def test_anonymous_and_forged_session_cannot_render_learning_pages(self):
        self.assertEqual([r.label for r in self.app.radio], ["账号操作"])
        self.assertFalse((self.auth_root / "users").exists())
        self.app.session_state["auth_token"] = "not-a-real-session"
        self.app.session_state["role"] = "developer"
        self.app.session_state["navigation"] = "开发进度"
        self.app.run()
        self.assertEqual([r.label for r in self.app.radio], ["账号操作"])
        self.assertFalse(any("一步一步，成为 Agent" in m.value for m in self.app.markdown))

    def test_registration_confirmation_password_match_and_full_login_logout_flow(self):
        self.app.radio(key="auth_mode").set_value("注册账号").run()
        def fill(repeat=PASSWORD):
            self.app.text_input(key="register_username").set_value("Student")
            self.app.text_input(key="register_password").set_value(PASSWORD)
            self.app.text_input(key="register_repeat").set_value(repeat)
        fill("a mismatching long password")
        self.click("创建账号")
        self.assertTrue(any("不一致" in e.value for e in self.app.error))
        fill()
        self.click("创建账号")
        self.assertTrue(any("确认" in e.value for e in self.app.error))
        fill()
        self.app.checkbox(key="register_confirm").check()
        self.click("创建账号")
        self.assertTrue(self.app.session_state["recovery_receipt"]["code"])
        self.assertFalse((self.auth_root / "users").exists())
        self.click("我已妥善保存，去登录")
        self.login(password="incorrect")
        self.assertEqual([r.label for r in self.app.radio], ["账号操作"])
        self.login()
        self.assertIn("账号设置", self.app.radio(key="navigation").options)
        self.assertNotIn("开发进度", self.app.radio(key="navigation").options)
        token = self.app.session_state["auth_token"]
        self.assertEqual(self.auth.study_database(token).get_study_profile()[0].goals, "")
        self.assertNotIn("login_password", self.app.session_state)
        self.click("退出登录")
        self.assertIsNone(self.auth.authenticate(token))
        self.assertNotIn("auth_token", self.app.session_state)
        self.assertEqual([r.label for r in self.app.radio], ["账号操作"])

    def test_switch_account_clears_previous_user_profile_and_drafts(self):
        self.auth.register("student", PASSWORD, confirmed=True)
        self.auth.register("second", PASSWORD, confirmed=True)
        self.login()
        token = self.app.session_state["auth_token"]
        self.auth.study_database(token).save_profile(StudyProfile(goals="第一个人的私有目标"), expected_version=0, confirmed=True)
        self.app.radio(key="navigation").set_value("学习档案").run()
        self.assertEqual(self.app.text_area(key="profile_goals_1").value, "第一个人的私有目标")
        self.app.text_area(key="profile_goals_1").set_value("第一个人的临时草稿")
        self.click("退出登录")
        self.login("second")
        self.app.radio(key="navigation").set_value("学习档案").run()
        self.assertEqual(self.app.text_area(key="profile_goals_0").value, "")
        self.assertNotIn("profile_goals_1", self.app.session_state)

    def test_recovery_reset_and_new_login(self):
        _, code = self.auth.register("student", PASSWORD, confirmed=True)
        token = self.auth.login("student", PASSWORD)
        self.app.radio(key="auth_mode").set_value("找回密码").run()
        self.app.text_input(key="reset_username").set_value("student")
        self.app.text_input(key="reset_code").set_value(code)
        self.app.text_input(key="reset_password").set_value(NEW_PASSWORD)
        self.app.text_input(key="reset_repeat").set_value(NEW_PASSWORD)
        self.app.checkbox(key="reset_confirm").check()
        self.click("重置密码")
        self.assertIsNone(self.auth.authenticate(token))
        self.assertNotEqual(self.app.session_state["recovery_receipt"]["code"], code)
        self.click("我已妥善保存，去登录")
        self.login(password=NEW_PASSWORD)
        self.assertEqual(self.app.radio(key="navigation").value, "学习概览")

    def test_password_change_signs_out_and_session_revocation_blocks_next_action(self):
        self.auth.register("student", PASSWORD, confirmed=True)
        self.login()
        token = self.app.session_state["auth_token"]
        self.app.radio(key="navigation").set_value("账号设置").run()
        self.app.text_input(key="change_current").set_value(PASSWORD)
        self.app.text_input(key="change_password").set_value(NEW_PASSWORD)
        self.app.text_input(key="change_repeat").set_value(NEW_PASSWORD)
        self.app.checkbox(key="change_confirm").check()
        self.click("更新密码")
        self.assertIsNone(self.auth.authenticate(token))
        self.assertNotIn("auth_token", self.app.session_state)
        self.click("我已妥善保存，去登录")
        self.login(password=NEW_PASSWORD)
        self.auth.logout(self.app.session_state["auth_token"])
        self.app.run()
        self.assertEqual([r.label for r in self.app.radio], ["账号操作"])
        self.assertNotIn("auth_token", self.app.session_state)


if __name__ == "__main__":
    unittest.main()
