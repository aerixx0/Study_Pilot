# StudyPilot：每次只学一个模块

先运行程序，然后按顺序阅读。第一周用 8 小时可以这样分配：安装和体验 1 小时、模块 1 练习 2 小时、模块 2 练习 2 小时、模块 3 练习 2 小时、复盘 1 小时。不需要现在理解所有 SQL 或界面代码。

## 模块 1：数据模型与校验（studypilot/models.py）

**解决什么问题**：统一“一个任务有哪些字段”，拒绝空标题、无效日期、负时长；保存未来排课需要的时间和设备约束。

**Python 知识**：变量、元组、字典、`@dataclass`、函数、`if` 判断、异常。`TaskInput` 可以理解成任务表格的一行；`validated()` 是提交前的检查员。`default_factory` 给每份档案创建独立字典，避免两份档案意外共享同一份可修改数据。

**Windows 上实验**：在项目根目录执行 `py` 进入交互环境，然后逐行输入：

```python
from datetime import date
from studypilot.models import TaskInput
task = TaskInput("写一个问候程序", "Python", date.today().isoformat(), 30)
task.validated()
```

最后一行返回字典，不会写数据库。把第一项改成空字符串，再调用 `validated()`，观察中文错误。输入 `exit()` 退出。

**亲自改哪几行**：搜索 `max_session_minutes: int = 45`，改成 `30`；搜索 `preference: str`，把默认偏好改成自己的话。它们只影响未保存的默认档案；已保存的资料应在界面修改。暂时不要改科目常量，因为它会影响已有数据的校验。

**如何测试**：`py -m unittest tests.test_database -v`。另外启动界面，检查尚未保存的默认档案是否显示 30 分钟；已有档案不需要删除。

## 模块 2：SQLite 数据库（studypilot/database.py）

**解决什么问题**：程序关闭后任务仍存在；创建、修改、删除与学习记录都先要求确认。数据库用版本号识别旧页面，避免覆盖刚刚保存的新内容。

**Python 知识**：类与方法、`with` 上下文管理器、`Path`、JSON、关键字参数。SQL 的 `?` 把用户输入当成数据，不能把任务标题当作 SQL 执行。事务让任务修改和历史记录一起成功或一起回滚。

**Windows 上实验**：运行 `py`，在交互环境中输入：

```python
from datetime import date
from studypilot.database import Database
from studypilot.models import TaskInput
db = Database("scratch.db")
task = TaskInput("测试任务", "数学", date.today().isoformat(), 20)
db.create_task(task)  # 会提示需要确认，不会保存
db.create_task(task, confirmed=True)  # 实验中手动明确确认
db.get_tasks()
```

退出 Python 后重新打开，再执行 `Database("scratch.db").get_tasks()`，任务仍然存在。此处使用独立实验数据库 `scratch.db`，不会影响应用数据；退出后可删除该实验文件，它也被 `.gitignore` 忽略。

**亲自改哪几行**：只搜索 `请先勾选确认，再提交更改。`，把提示文字改成自己更容易理解的句子。保留 `if confirmed is not True`，先不要改表结构或删除逻辑。

**如何测试**：`py -m unittest tests.test_database.DatabaseTests -v`，然后在界面尝试不勾确认提交。你在实验脚本中手动传 `True`，不代表未来可以让大模型自行确认。

## 模块 3：Streamlit 界面（app.py）

**解决什么问题**：不需要命令行输入任务，把表单值交给数据层，并显示成功和错误。`st.form` 等你点击提交才处理填写内容；成功后 `st.rerun()` 重新读取数据库。

**Python 知识**：模块导入、函数调用、`if/elif`、列表推导式、`lambda`。`commit()` 只在提交按钮被点击后执行操作，复用同一套错误处理。创建和记录表单提交后会清空，防止误复用已勾选的确认。

**Windows 上运行**：

```powershell
.\.venv\Scripts\python.exe -m streamlit run app.py
```

**亲自改哪几行**：搜索 `把大目标变成小行动`，换成自己的首页副标题。只改文字，不改 `key` 和提交逻辑。Streamlit 通常会提示或自动刷新；重新打开页面检查文字。

**如何测试**：`.\.venv\Scripts\python.exe -m unittest tests.test_app -v`。这些测试模拟点击表单并检查真实 SQLite 内容，使用临时数据库。

## 模块 4：真实学习统计（studypilot/progress.py）

**解决什么问题**：按周汇总实际分钟和科目比例；没有任务时不会乱算完成率，没有记录时不画假图。

**Python 知识**：日期运算、`timedelta`、列表筛选、`defaultdict`、除法、纯函数。`get_progress()` 只使用传入数据，不写数据库，容易单独验证。

**Windows 上实验**：进入 `py`，输入：

```python
from datetime import date
from studypilot.progress import week_bounds, get_progress
week_bounds(date(2026, 10, 11))
get_progress([], [], date(2026, 10, 11))["completion_rate"]
```

第一条得到周一和下一周周一；第二条得到 `None`，意思是没有任务，无法定义完成率。

**亲自改哪几行**：先不要改变统计口径。打开 `tests/test_database.py`，搜索 `test_empty_progress_does_not_claim_zero_completion`，在末尾添加 `self.assertEqual(result["weekly_history"], {})`。这是你写的第一条自动化断言。

**如何测试**：`py -m unittest tests.test_database.ProgressTests -v`。在界面记录一次真实学习，查看“实际分钟”是否相等；预计时长可以不同。

## 这一阶段只需掌握的路径

```text
你填写任务 → app.py 收集输入 → models.py 检查输入
          → database.py 保存 SQLite → progress.py 汇总 → app.py 展示
```

下阶段再学“规则如何使用设备与时间约束排课”。之后才学习“模型如何选工具、提出修改，以及为什么模型不能替用户确认”。
