"""Streamlit AppTest 实际提交表单，验证从 UI 到 SQLite 的完整路径。"""

from datetime import date
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from streamlit.testing.v1 import AppTest

from studypilot.database import Database


ROOT = Path(__file__).resolve().parents[1]


class AppTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.db_path = Path(self.temp.name) / "study.db"
        env = patch.dict(os.environ, {"STUDYPILOT_DB": str(self.db_path), "OPENAI_API_KEY": ""})
        env.start()
        self.addCleanup(env.stop)
        self.app = AppTest.from_file(str(ROOT / "app.py"), default_timeout=20).run()

    def click(self, label):
        next(button for button in self.app.button if button.label == label).click().run()
        self.assertEqual(len(self.app.exception), 0)

    def navigate(self, page):
        self.app.radio(key="navigation").set_value(page).run()
        self.assertEqual(len(self.app.exception), 0)

    def test_empty_app_and_all_pages_render(self):
        self.assertEqual(len(self.app.exception), 0)
        for page in ("学习档案", "学习任务", "学习记录", "开发进度", "学习概览"):
            self.navigate(page)
        self.assertEqual(Database(self.db_path).get_tasks(), [])
        self.assertTrue(any("AI 未启用" in message.value for message in self.app.info))

    def test_task_record_edit_and_delete_flow(self):
        db = Database(self.db_path)
        self.navigate("学习任务")
        self.app.text_input(key="new_title").set_value("周末 Python 练习")
        self.click("创建任务")
        self.assertTrue(any("确认" in error.value for error in self.app.error))
        self.assertEqual(db.get_tasks(), [])
        self.app.text_input(key="new_title").set_value("周末 Python 练习")
        self.app.checkbox(key="create_confirm").check()
        self.click("创建任务")
        task = db.get_tasks()[0]
        task_id = task["id"]
        self.app.selectbox(key=f"edit_{task_id}_1_status").set_value("已完成")
        self.click("保存任务修改")
        self.assertEqual(db.get_task(task_id)["status"], "待开始")
        self.app.selectbox(key=f"edit_{task_id}_1_status").set_value("已完成")
        self.app.checkbox(key=f"edit_{task_id}_1_confirm").check()
        self.click("保存任务修改")
        self.assertEqual(db.get_task(task_id)["status"], "已完成")
        self.assertEqual(db.get_sessions(), [])
        self.navigate("学习记录")
        self.app.number_input(key="record_minutes").set_value(37)
        self.click("保存学习记录")
        self.assertEqual(db.get_sessions(), [])
        self.app.number_input(key="record_minutes").set_value(37)
        self.app.checkbox(key="record_confirm").check()
        self.click("保存学习记录")
        self.assertEqual(db.get_sessions()[0]["minutes"], 37)
        self.navigate("学习概览")
        self.assertEqual(len(self.app.exception), 0)
        self.assertEqual(len(self.app.get("vega_lite_chart")), 2)
        self.navigate("学习任务")
        self.click("删除任务")
        self.assertEqual(len(db.get_tasks()), 1)
        self.app.checkbox(key=f"edit_{task_id}_2_delete_confirm").check()
        self.click("删除任务")
        self.assertEqual(db.get_tasks(), [])
        self.assertEqual(len(db.get_sessions()), 1)
        self.navigate("学习记录")
        session_id = db.get_sessions()[0]["id"]
        self.click("删除学习记录")
        self.assertEqual(len(db.get_sessions()), 1)
        self.app.checkbox(key=f"session_delete_confirm_{session_id}").check()
        self.click("删除学习记录")
        self.assertEqual(db.get_sessions(), [])

    def test_profile_save_requires_confirmation_and_survives_new_app(self):
        self.navigate("学习档案")
        self.click("保存档案")
        self.assertEqual(Database(self.db_path).get_study_profile()[1], 0)
        next(box for box in self.app.checkbox if box.label == "我确认保存以上学习档案").check()
        self.click("保存档案")
        self.assertEqual(Database(self.db_path).get_study_profile()[1], 1)
        fresh = AppTest.from_file(str(ROOT / "app.py"), default_timeout=20).run()
        fresh.radio(key="navigation").set_value("学习档案").run()
        self.assertEqual(len(fresh.exception), 0)
        self.assertFalse(any("默认草稿" in item.value for item in fresh.info))

    def test_invalid_title_is_rejected_with_chinese_message(self):
        self.navigate("学习任务")
        self.app.checkbox(key="create_confirm").check()
        self.click("创建任务")
        self.assertTrue(any("任务标题" in item.value for item in self.app.error))
        self.assertEqual(Database(self.db_path).get_tasks(), [])

    def test_configured_key_is_never_displayed_or_called(self):
        with patch.dict(os.environ, {"OPENAI_API_KEY": "test-only-secret-marker"}):
            self.app.run()
        self.assertTrue(any("AI 功能尚未实现" in item.value for item in self.app.info))
        visible_text = " ".join(item.value for collection in (self.app.info, self.app.markdown, self.app.caption) for item in collection)
        self.assertNotIn("test-only-secret-marker", visible_text)


if __name__ == "__main__":
    unittest.main()
