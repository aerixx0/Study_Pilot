"""运行入口：python -m streamlit run app.py。界面只负责展示和收集输入。"""

from datetime import date, timedelta
import os
from pathlib import Path
import sqlite3

import streamlit as st

from studypilot.database import ConfirmationRequired, ConflictError, Database
from studypilot.models import DAYS, DEVICES, LEVELS, PRIORITIES, SPEEDS, STATUSES, SUBJECTS, StudyProfile, TaskInput, ValidationError
from studypilot.progress import get_progress


ROOT = Path(__file__).resolve().parent


def commit(action, success_message):
    """仅在按钮提交后调用；错误保留在页面，成功刷新并显示一次提示。"""
    try:
        action()
    except (ConfirmationRequired, ConflictError, ValidationError) as exc:
        st.error(str(exc))
    except sqlite3.Error:
        st.error("数据库暂时无法写入。请检查磁盘空间、文件权限或其他打开数据库的程序，再重试。")
    else:
        st.session_state["notice"] = success_message
        st.rerun()


def profile_page(db):
    profile, version = db.get_study_profile()
    st.header("学习档案")
    st.caption("只记录学习需要的信息，无需姓名、学校、账号或住址。")
    if not version:
        st.info("这是默认草稿：每周 8 小时，周五至周日使用电脑。确认保存后才成为你的档案。")
    with st.form(f"profile_{version}"):
        goals = st.text_area("学习目标", profile.goals, max_chars=2000)
        left, right = st.columns(2)
        hours = left.number_input("每周学习时间（小时）", min_value=0.5, max_value=40.0, value=float(profile.weekly_hours), step=0.5)
        speed = right.selectbox("学习速度", SPEEDS, index=SPEEDS.index(profile.speed))
        maximum = left.number_input("单次学习时长上限（分钟）", 1, 180, profile.max_session_minutes)
        preference = right.text_input("学习偏好", profile.preference, max_chars=500)
        st.subheader("各科目基础与优先级")
        levels, priorities = {}, {}
        for subject in SUBJECTS:
            a, b = st.columns(2)
            levels[subject] = a.selectbox(f"{subject} · 当前水平", LEVELS, index=LEVELS.index(profile.levels[subject]))
            priorities[subject] = b.selectbox(f"{subject} · 优先级", PRIORITIES, index=PRIORITIES.index(profile.priorities[subject]))
        st.subheader("每一天的时间与设备")
        st.caption("填写额外学习时间；0 分钟代表这天不安排学习。各天合计应至少覆盖每周学习时间。")
        availability = {}
        for day in DAYS:
            a, b = st.columns(2)
            amount = a.number_input(f"{day} · 可用分钟", 0, 1440, profile.availability[day]["minutes"], step=15)
            devices = b.multiselect(f"{day} · 可用设备", DEVICES, default=profile.availability[day]["devices"])
            availability[day] = {"minutes": amount, "devices": devices}
        confirmed = st.checkbox("我确认保存以上学习档案")
        if st.form_submit_button("保存档案", type="primary"):
            updated = StudyProfile(goals, hours, speed, preference, maximum, levels, priorities, availability)
            commit(lambda: db.save_profile(updated, expected_version=version, confirmed=confirmed), "学习档案已保存。")


def task_fields(task=None, prefix="new"):
    """新建和编辑共用表单字段，减少重复代码；每个组件用独立 key。"""
    current = task or {}
    title = st.text_input("任务标题", current.get("title", ""), max_chars=120, key=f"{prefix}_title")
    a, b = st.columns(2)
    subject = a.selectbox("科目", SUBJECTS, index=SUBJECTS.index(current.get("subject", "Python")), key=f"{prefix}_subject")
    due = b.date_input("截止日期", date.fromisoformat(current["due_date"]) if task else date.today(), key=f"{prefix}_due")
    duration = a.number_input("预计学习时间（分钟）", 1, 1440, current.get("estimated_minutes", 45), key=f"{prefix}_estimate")
    priority = b.selectbox("优先级", PRIORITIES, index=PRIORITIES.index(current.get("priority", "中")), key=f"{prefix}_priority")
    status = a.selectbox("状态", STATUSES, index=STATUSES.index(current.get("status", "待开始")), key=f"{prefix}_status")
    computer = b.checkbox("这项任务需要电脑", bool(current.get("requires_computer", False)), key=f"{prefix}_computer")
    notes = st.text_area("任务备注", current.get("notes", ""), max_chars=2000, key=f"{prefix}_notes")
    return TaskInput(title, subject, due.isoformat(), duration, priority, status, computer, notes)


def task_rows(tasks, sessions):
    totals = {}
    for session in sessions:
        totals[session["task_id"]] = totals.get(session["task_id"], 0) + session["minutes"]
    return [{"编号": t["id"], "任务": t["title"], "科目": t["subject"], "状态": t["status"], "截止日期": t["due_date"],
             "优先级": t["priority"], "预计分钟": t["estimated_minutes"], "实际分钟": totals.get(t["id"], 0),
             "需要电脑": bool(t["requires_computer"])} for t in tasks]


def tasks_page(db):
    st.header("学习任务")
    st.caption("先写一个可以完成的小任务，例如：写一个输入名字并打招呼的 Python 程序。")
    with st.expander("＋ 创建任务", expanded=True):
        with st.form("create_task", clear_on_submit=True):
            task = task_fields()
            confirmed = st.checkbox("我确认创建以上任务", key="create_confirm")
            if st.form_submit_button("创建任务", type="primary"):
                commit(lambda: db.create_task(task, confirmed=confirmed), "任务已创建。")
    tasks = db.get_tasks()
    a, b = st.columns(2)
    subject_filter = a.selectbox("按科目筛选", ("全部",) + SUBJECTS)
    status_filter = b.selectbox("按状态筛选", ("全部",) + STATUSES)
    visible = [t for t in tasks if (subject_filter == "全部" or t["subject"] == subject_filter) and (status_filter == "全部" or t["status"] == status_filter)]
    if not visible:
        st.info("这里还没有符合条件的任务。创建后会保存在本地，重启也会保留。")
        return
    st.dataframe(task_rows(visible, db.get_sessions()), hide_index=True, width="stretch")
    by_id = {t["id"]: t for t in visible}
    selected = st.selectbox("选择要编辑的任务", list(by_id), format_func=lambda i: f"#{i} · {by_id[i]['title']}", key="edit_selection")
    current = by_id[selected]
    prefix = f"edit_{selected}_{current['version']}"
    with st.expander("编辑任务 / 标记完成", expanded=True):
        with st.form(prefix):
            task = task_fields(current, prefix)
            confirmed = st.checkbox("我确认保存以上任务修改", key=f"{prefix}_confirm")
            if st.form_submit_button("保存任务修改", type="primary"):
                commit(lambda: db.update_task(selected, task, expected_version=current["version"], confirmed=confirmed), "任务修改已保存。")
    with st.expander("删除任务"):
        st.warning(f"即将删除 #{selected}：{current['title']}。任务将从任务列表隐藏，已有学习记录和变更历史仍会保留。")
        with st.form(f"delete_{prefix}"):
            confirmed = st.checkbox("我确认删除这个任务", key=f"{prefix}_delete_confirm")
            if st.form_submit_button("删除任务"):
                commit(lambda: db.delete_task(selected, expected_version=current["version"], confirmed=confirmed), "任务已删除，已有学习记录保留。")


def records_page(db):
    st.header("学习记录")
    st.caption("每次学习结束后记录实际分钟。同一天可以记录多次；标记任务完成不会自动增加学习时间。")
    tasks = db.get_tasks()
    if tasks:
        task_lookup = {t["id"]: t for t in tasks}
        with st.form("record_session", clear_on_submit=True):
            selected = st.selectbox("关联任务", list(task_lookup), format_func=lambda i: f"#{i} · {task_lookup[i]['title']}", key="record_task")
            a, b = st.columns(2)
            day = a.date_input("实际学习日期", date.today(), max_value=date.today(), key="record_date")
            duration = b.number_input("实际学习时间（分钟）", 1, 1440, 30, key="record_minutes")
            note = st.text_input("学习记录备注", max_chars=1000, key="record_note")
            confirmed = st.checkbox("我确认这次学习确实发生并保存记录", key="record_confirm")
            if st.form_submit_button("保存学习记录", type="primary"):
                commit(lambda: db.log_session(selected, day.isoformat(), duration, note, confirmed=confirmed), "真实学习记录已保存。")
    else:
        st.info("请先创建一个任务，再记录学习时间。")
    sessions = db.get_sessions()
    if not sessions:
        st.info("还没有学习记录。图表会在你记录真实学习后出现。")
        return
    st.dataframe([{"编号": s["id"], "日期": s["study_date"], "任务": s["task_title"], "科目": s["subject"], "分钟": s["minutes"],
                   "备注": s["note"], "任务已删除": bool(s["deleted_at"])} for s in sessions], hide_index=True, width="stretch")
    with st.expander("纠正误记的学习时间"):
        st.caption("删除错误记录后，可以重新填写正确记录。删除学习记录会相应更新统计。")
        session_lookup = {s["id"]: s for s in sessions}
        selected = st.selectbox("选择错误记录", list(session_lookup), format_func=lambda i: f"#{i} · {session_lookup[i]['study_date']} · {session_lookup[i]['minutes']} 分钟 · {session_lookup[i]['task_title']}")
        with st.form(f"delete_session_{selected}"):
            confirmed = st.checkbox("我确认删除这条学习记录", key=f"session_delete_confirm_{selected}")
            if st.form_submit_button("删除学习记录"):
                commit(lambda: db.delete_session(selected, confirmed=confirmed), "错误学习记录已删除。")


def progress_page(db):
    st.header("学习概览")
    day = st.date_input("查看哪一周", date.today())
    tasks, sessions = db.get_tasks(include_deleted=True), db.get_sessions()
    progress = get_progress(tasks, sessions, day)
    st.caption(f"{progress['start']} 至 {progress['end'] - timedelta(days=1)} · 周一开始")
    a, b, c = st.columns(3)
    rate = progress["completion_rate"]
    a.metric("完成率", "暂无任务" if rate is None else f"{rate:.0%}", help="本周截止的未删除任务中，目前已完成任务的比例。查看过去周时也按当前任务状态计算，不是当时快照。")
    b.metric("实际时长", f"{progress['actual_minutes'] / 60:.1f} 小时", help=f"精确时长：{progress['actual_minutes']} 分钟。按实际学习日期统计，包括已删除任务的学习记录。")
    c.metric("已完成任务", f"{progress['completed_count']} / {progress['task_count']}", help="已完成数量 / 本周到期的未删除任务数量。")
    st.caption("完成率依据任务当前状态；历史时长依据原始学习日期。预计时长不计入实际学习时间。")
    if progress["subjects"]:
        st.subheader("本周各科目投入")
        chart = [{"科目": subject, "实际分钟": amount} for subject, amount in progress["subjects"].items()]
        st.bar_chart(chart, x="科目", y="实际分钟", color="#377568")
        st.dataframe([{"科目": s, "实际分钟": m, "投入比例": f"{progress['subject_shares'][s]:.1%}"} for s, m in progress["subjects"].items()], hide_index=True, width="stretch")
    else:
        st.info("这周没有真实学习记录，因此不显示投入比例或虚构图表。")
    if progress["weekly_history"]:
        st.subheader("每周真实学习历史")
        st.bar_chart([{"周一日期": w, "实际分钟": m} for w, m in progress["weekly_history"].items()], x="周一日期", y="实际分钟", color="#377568")
        st.caption("只显示有记录的周；没有记录的周不等于没有学习。")
    st.subheader("本周未完成任务")
    if progress["incomplete"]:
        st.dataframe(task_rows(progress["incomplete"], sessions), hide_index=True, width="stretch")
    else:
        st.write("本周没有未完成的到期任务。")
    if progress["overdue"]:
        st.subheader("所选日期之前的逾期任务")
        st.dataframe(task_rows(progress["overdue"], sessions), hide_index=True, width="stretch")
    profile, version = db.get_study_profile()
    st.subheader("学习目标")
    st.write(profile.goals)
    st.caption("" if version else "以上为未保存的默认草稿。")
    st.caption("第一版的目标是文字描述，尚未绑定可衡量的里程碑，因此不计算目标完成百分比。")
    events = db.get_events()
    if events:
        with st.expander("任务变更历史（时间为 UTC）"):
            st.dataframe([{"任务编号": e["task_id"], "操作": e["action"], "时间": e["created_at"]} for e in events], hide_index=True, width="stretch")


def main():
    st.set_page_config(page_title="StudyPilot · 学习驾驶舱", page_icon="📚", layout="wide")
    st.markdown("""<style>
        .block-container {max-width: 1100px; padding-top: 2rem;}
        h1,h2,h3 {letter-spacing: -0.025em;}
        [data-testid="stMetric"] {background:#F0F1EE; border-radius:12px; padding:14px;}
        [data-testid="stMetricValue"] {font-size:1.5rem;}
        </style>""", unsafe_allow_html=True)
    st.title("StudyPilot")
    st.caption("把大目标变成小行动 · 本地学习驾驶舱 · v0.1.0")
    if "notice" in st.session_state:
        st.success(st.session_state.pop("notice"))
    with st.sidebar:
        st.title("📚 StudyPilot")
        page = st.radio("导航", ("学习概览", "学习档案", "学习任务", "学习记录", "开发进度"), key="navigation")
        st.divider()
        st.caption("第一阶段 · 本地单用户版")
        if os.getenv("OPENAI_API_KEY", "").strip():
            st.info("检测到 API Key 环境变量。AI 功能尚未实现，本版本不会调用模型。")
        else:
            st.info("AI 未启用：未配置 API Key。档案、任务和统计正常可用。")
        st.caption("自动排课尚未实现；档案中的日期和设备限制已保存，供第二阶段使用。")
    try:
        db = Database(os.getenv("STUDYPILOT_DB") or ROOT / "data" / "studypilot.db")
        if page == "学习档案":
            profile_page(db)
        elif page == "学习任务":
            tasks_page(db)
        elif page == "学习记录":
            records_page(db)
        elif page == "学习概览":
            progress_page(db)
        else:
            st.header("一步一步构建学习 Agent")
            st.write("✅ 第一阶段：学习档案、任务增删改、完成状态、实际学习记录、SQLite 和基础统计。")
            st.write("下一步：按每周预算、每天时间和设备限制，生成规则式学习计划。")
            st.write("第三阶段：OpenAI 工具调用循环、只读工具、修改提案和用户确认后执行。")
            st.write("第四阶段：完善建议、目标里程碑、图表和开源协作。")
            st.info("本版尚不是 AI Agent。没有聊天假入口，也不会把规则逻辑标成大模型。")
    except (ValidationError, sqlite3.Error, OSError) as exc:
        if isinstance(exc, ValidationError):
            st.error(str(exc))
        else:
            st.error("无法打开本地数据库。请检查 STUDYPILOT_DB 路径、写入权限和磁盘空间。数据库不会被自动覆盖。")
        st.stop()


if __name__ == "__main__":
    main()
